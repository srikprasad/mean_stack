'use Strict';
module.exports = function(){
    console.log('Hello World!!');
}

